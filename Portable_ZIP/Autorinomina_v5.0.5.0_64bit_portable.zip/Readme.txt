README for Autorinomina
-----------------------

Autorinomina is a freeware software to rename multiple files at same time.
With an user friendly interface allows user to rename easily a large 
variety of files. It's own speciality is rename TV Series with a filter
that is able to clean the filenames from special characters and useless
words. Among it's features can read the metadata informations like
EXIF/IPTC/ID3 TAGS a good way to rename photos and audio files
and much more.


Autorinomina runs on Windows Vista / 7 / 8 / 10 (32-bit and 64-bit) operating systems


Prerequisites
-----------------------

To allow its proper functioning you need to install the package,
      Microsoft .NET Framework 4.5
To check if you have already installed, look up:
Control Panel > Add or Remove Programs (Programs and Features)

When it is necessary you can download and install from here:
https://www.microsoft.com/en-us/download/details.aspx?id=30653


License
-----------------------
Read License.txt for more information about license.



Autorinomina Copyright (c) 2009-2018 Stefano Gottardo
